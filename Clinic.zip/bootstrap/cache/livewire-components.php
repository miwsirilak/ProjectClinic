<?php return array (
  'admin.admin-dashboard-component' => 'App\\Http\\Livewire\\Admin\\AdminDashboardComponent',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
);