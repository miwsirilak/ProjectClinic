<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h4 mb-0 text-gray-800">คลินิกโรคผิวหนัง แพทย์หญิงปิยะรัตน์</h1>
            
            
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      
                      <div class="h6 mb-0 font-weight-bold text-gray-800">นัดหมายแพทย์</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-user-lock fa-2x text-rgb-300" style="color:rgb(18, 134, 67);"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      
                      <div class="h6 mb-0 font-weight-bold text-gray-800">ลงทะเบียนผู้ป่วย</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-address-book fa-2x text-rgb-300" style="color:rgb(18, 134, 67);"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            
                      
                      

            <!-- Pending Requests Card Example -->
            
                      
                      

          <!-- Content Row -->

          <div class="row">

           <!-- Area Chart -->
<div class="col-xl-8 col-lg-7">
  <div class="card shadow mb-4">
    <!-- Card Header - Dropdown -->
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">Social Distancing ลดการปฏิสัมพันธ์ใกล้ชิดกันระหว่างบุคคลเพื่อลดโอกาสการรับเชื้อ</h6>
    </div>
    <!-- Card Body -->
    <div class="card-body">
    <img src="<?php echo e(asset('img/Social_Distancing.png')); ?>" alt="Girl in a jacket" width="600" height="450">
      <!-- <div class="chart-area">
        <canvas id="myAreaChart"></canvas>
      </div> -->
    </div>
  </div>
</div>

<!-- Pie Chart -->
<div class="col-xl-4 col-lg-5">
  <div class="card shadow mb-4">
    
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">บทความสุขภาพ</h6>
      <div class="dropdown no-arrow">
        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
          <div class="dropdown-header">Dropdown Header:</div>
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <div class="chart-pie pt-4 pb-2">
        <img src="<?php echo e(asset('img/shutterstock.jpg')); ?>" alt="Girl in a jacket" width="280" height="250">
      </div>
      <div class="mt-4 text-center small">
        <span class="mr-2">
        <h6 class="m-0 font-weight-bold " style="color:rgb(252, 117, 229)">ความรู้เกี่ยวกับโรคผิวหนัง </h6>
          
        </span>
      </div>
    </div>
  </div>
</div>
</div> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('templete.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/page_user/index.blade.php ENDPATH**/ ?>