

<?php $__env->startSection('title', 'Base page'); ?>
<title>Clinic</title>

<?php $__env->startSection('content'); ?>

    <div class="container mt-2">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>คำเตือน!</strong> มีปัญหาบางอย่างเกี่ยวกับข้อมูลที่คุณป้อน<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <br>

        <?php if(Auth::user()): ?>
            <div class="card">
                <h5 class="card-header text-white" style="background-color:#46a7a2;">นัดหมายแพทย์</h5>
                <div class="card-body" style="background-color:#e8ecec;">
                    <form action="<?php echo e(route('events.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>ชื่อ:</strong>
                                    <input type="text" name="title" class="form-control" placeholder="ชื่อ" required
                                        value="<?php echo e(Auth::user()->name); ?>">
                                </div>
                            </div>

                            <form>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label for="party"><strong>วันที่:</strong>
                                        <input type="date" value="" name="date" class="form-control" required>
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="booked" id="booked"
                                            value="จองแล้ว" checked>
                                        <label class="form-check-label" for="booked">
                                            จองคิว
                                        </label>
                                    </div>
                                </div>
                            </form>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>อาการ</strong>
                                    <select class="form-control" id="exampleFormControlSelect1" name="sympotm">
                                        <option value="ไม่ระบุอาการ">ไม่ระบุอาการ</option>
                                        <option value="ผิวหนัง">ผิวหนัง</option>
                                        <option value="ผม">ผม</option>
                                        <option value="เล็บ">เล็บ</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-success">ยืนยัน</button>
                                <a class="btn btn-danger" href="<?php echo e(route('events.index')); ?>">กลับ</a>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        <?php endif; ?>


    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\Clinic\resources\views/events/create.blade.php ENDPATH**/ ?>