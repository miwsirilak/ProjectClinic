

<?php $__env->startSection('title', 'Base page'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h4>กำหนดวันหยุด</h4>
                </div>
                <div class="pull-right">
                    <a class="btn btn-success" href="<?php echo e(route('workingdays.create')); ?>">เพิ่มวันหยุด</a>
                    <a class="btn btn-warning" href="<?php echo e(route('fullcalendarDates')); ?>">ปฎิทินการนัดหมายแพทย์</a>
                </div>
            </div>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <br>
        <table class="table table-bordered">
            <tr class="text-white" style="background-color:#e99292;">
                
                <th>วันที่</th>
                <th>หัวข้อ</th>
                
                <th width="280px">ลบวันหยุด</th>
            </tr>
            <?php $__currentLoopData = $workingdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workingday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background-color:#ffffff;">
                    
                    <td><?php echo e($workingday->date); ?></td>
                    <td><?php echo e($workingday->title); ?></td>
                    
                    <td>
                        <form action="<?php echo e(route('workingdays.destroy', $workingday->id)); ?>" method="POST">

                            

                            


                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">ยกเลิกวันหยุด</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <?php echo $workingdays->links(); ?>


    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/workingdays/index.blade.php ENDPATH**/ ?>