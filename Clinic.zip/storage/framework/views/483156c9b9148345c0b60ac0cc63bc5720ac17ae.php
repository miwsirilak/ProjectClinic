

<!DOCTYPE html>
<html>
<head>
    <title>Laravel Blade If Multiple Conditions Example</title>
</head>
<body>
    <h1>Laravel Blade If Multiple Conditions Example - NiceSnippets.com</h1>
    <?php if(count($records) === 1): ?>
        <p>I have one record!</p>
    <?php elseif(count($records) === 2): ?>
        <p>I have two records!</p>
    <?php elseif(count($records) > 1): ?>
        <p>I have multiple records!</p>
    <?php else: ?>
        <p>I don't have any records!</p>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/page_user/cards.blade.php ENDPATH**/ ?>