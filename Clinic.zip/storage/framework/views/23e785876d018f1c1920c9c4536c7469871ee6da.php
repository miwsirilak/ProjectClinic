<div>
    <h1>User/Customer Dashboard</h1>
</div>
<?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>