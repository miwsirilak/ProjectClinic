<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Asus\EX_Project\Clinic\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>