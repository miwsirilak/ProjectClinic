

<?php $__env->startSection('title', 'Base page'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-2">

        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left text-info" >
                    <h3>ประวัติการนัดหมายแพทย์</h3>
                </div>
                <div class="pull-right">
                    <a class="btn btn-Warning" href="<?php echo e(route('events.create')); ?>">นัดหมายแพทย์</a>

                    <?php if(Auth::user()): ?>
                        <?php if(Auth::user()->role === 'admin'): ?>
                            <a class="btn btn-info" href="<?php echo e(route('fullcalendarDates')); ?>">ปฎิทินการนัดหมายแพทย์</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <br>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        
        <?php if(Auth::user()): ?> 
            <?php if(Auth::user()->role === 'admin'): ?> 
                <table class="table table-bordered">
                    <tr class="text-white" style="background-color:#435D7D;">
                        <th>ลำดับ</th>
                        <th>ชื่อ</th>
                        <th>อาการ</th>
                        <th>สถานะการจอง</th>
                        <th>วันที่</th>
                        <th width="280px">เลื่อนวันนัด | ยกเลิกวันนัด</th>
                    </tr>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="background-color:#ffffff;">
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($event->title); ?></td>
                            <td><?php echo e($event->sympotm); ?></td>
                            <td><?php echo e($event->booked); ?></td>
                            <td><?php echo e($event->date); ?></td>
                            <td>
                                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST">

                                    

                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('events.edit', $event->id)); ?>">เลื่อนวันนัด</a>

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('ท่านต้องการยกเลิกวันนัดใช่หรือไม่ ?')">ยกเลิกวันนัด</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        <?php endif; ?>

        <?php echo $events->links(); ?>

        


        
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::user()): ?> 
                <?php if(Auth::user()->name === $event->username): ?> 
                    <div class="card text-center" style="background-color:#ffffff;">
                        <div class="card-header text-white" style="background-color:#e99292;">
                            ประวัติการนัดหมายแพทย์
                            
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-success">จองแล้ว</h5>
                            <h5 class="card-title">ชื่อ : <?php echo e($event->title); ?></h5>
                            <p class="card-text">อาการ : <?php echo e($event->sympotm); ?></p>
                            <p class="card-text">วันที่จอง : <?php echo e($event->date); ?></p>
                        </div>
                        <div class="card-footer text-muted" style="background-color:#e5e9e9;">
                            <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST">
                                <a class="btn btn-primary" href="<?php echo e(route('events.edit', $event->id)); ?>">เลื่อนวันนัด</a>

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('ท่านต้องการยกเลิกวันนัดใช่หรือไม่ ?')">ยกเลิกวันนัด</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        


        
        
        

    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/events/index.blade.php ENDPATH**/ ?>