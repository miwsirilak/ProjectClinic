
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD Example from scratch - ItSolutionStuff.com</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('bookings.create')); ?>"> Create New event</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Sympotm</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($event->title); ?></td>
            <td><?php echo e($event->sympotm); ?></td>
            <td>
                <form action="<?php echo e(route('bookings.destroy',$event->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('bookings.show',$event->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('bookings.edit',$event->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $bookings->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bookings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/bookings/index.blade.php ENDPATH**/ ?>