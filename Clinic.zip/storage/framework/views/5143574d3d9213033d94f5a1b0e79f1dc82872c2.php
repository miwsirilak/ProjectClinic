

<?php $__env->startSection('title', 'Base page'); ?>
<title>Clinic</title>

<?php $__env->startSection('content'); ?>
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <div class="container mt-2">

        <div class="card text-info bg-warning mb-3" style="max-width: 80rem;">
            <div class="card-header bg-white">
                <h5>ข้อมูลแพทย์</h5>
            </div>
            <div class="card-body">

                <div class="card mb-3" style="max-width: 1000px;">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('img/doctor.jpg')); ?>" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title">ข้อมูลแพทย์</h5>
                                <p class="card-text">ชื่อ : แพทย์หญิง ปิยะรัตน์</p>
                                <p class="card-text">โทร : 0655639744 (เฉพาะเวลาทำการ)</p>
                                <p class="card-text">ไลน์ : คลินิกโรคผิวหนัง พญ.ปิยะรัตน์</p>
                                <p class="card-text">Line : 0655639744s </p>
                                <p class="card-text">facebook : คลินิกโรคผิวหนัง พญ.ปิยะรัตน์</p>
                                <p class="card-text">Email : piyaratskinclinic@gmail.com</p>
                            </div>
                        </div>
                    </div>


                    


                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\Clinic\resources\views/page_user/dermatologist.blade.php ENDPATH**/ ?>