

<?php $__env->startSection('title', 'Base page'); ?>

<?php $__env->startSection('content'); ?>

<h1>Calendar</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/page_user/calen.blade.php ENDPATH**/ ?>