<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Post</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css"/>
    
</head>
<body>

    <div class="container mt-2">
    
    <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Post</h2>
                </div>
                <div class="pull-right mb-2">
                    <a class="btn btn-success" href="<?php echo e(route('posts.create')); ?>"> เพิ่มความรู้หรือข่าวสาร</a>
                </div>
            </div>
        </div>
       
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
       
        

        
        <div class="container">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <div class="media">
                    <a class="pull-left" href="#">
                      <img class="media-object" src="<?php echo e(Storage::url($post->image)); ?>" height="168" width="300">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading"><?php echo e($post->title); ?></h4>
                    <p class="text-right"><a href="https://www.w3schools.com/">เพิ่มเติม...</a></p>
                    <p><?php echo e($post->description); ?></p>
                    <ul class="list-inline list-unstyled">
                        <li><span><i class="glyphicon glyphicon-calendar"></i> 2 days, 8 hours </span></li>
                      <li>|</li>
                      <span><i class="glyphicon glyphicon-time"></i> 2 hours</span>
                      <li>|</li>
                      </ul>
                      
                      <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="POST">
        
                        <a class="btn btn-primary" href="<?php echo e(route('posts.edit',$post->id)); ?>">Edit</a>
       
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
          
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>

                 </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          
        
      
        <?php echo $posts->links(); ?>

    
    </body>
</html><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/posts/index.blade.php ENDPATH**/ ?>