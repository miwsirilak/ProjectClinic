
  
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>นัดหมายแพทย์</h2>
        </div>
        
    </div>
</div>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('appointments.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>ชื่อ:</strong>
                <input type="text" name="title" class="form-control" placeholder="ชื่อ">
            </div>
        </div>
        
        <form>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <label for="party"><strong>วันที่:</strong>
                    
                    <input type="date"  value=" " name="date" class="form-control">
                </label>
            </div>
        </form>

        
        
        
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>อาการที่มาพบแพทย์:</strong>
                <textarea class="form-control" style="height:150px" name="sympotm" placeholder="อาการที่มาพบแพทย์"></textarea>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-danger" href="<?php echo e(route('appointments.index')); ?>"> Back</a>
        </div>
    </div>
   
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('appointments.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/appointments/create.blade.php ENDPATH**/ ?>