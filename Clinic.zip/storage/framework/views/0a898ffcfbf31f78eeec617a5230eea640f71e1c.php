

<?php $__env->startSection('title', 'Base page'); ?>
<title>Clinic</title>

<?php $__env->startSection('content'); ?>

    <div class="container mt-2">

        <div class="card text-info mb-3" style="max-width: 80rem; background-color:#d1dddc;">
            <div class="card-header bg-white">
                <h5>แก้ไขข้อมูล (<?php echo e($user->role); ?>)</h5>
            </div>
            <div class="card-body">

                <div class="card mb-3" style="max-width: 1100px;">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            
                            <?php if(Auth::user()->role === 'admin'): ?>
                                <?php if(Auth::user()->name === $user->name): ?>
                                    <img src="<?php echo e(asset('img/doctors.PNG')); ?>" class="rounded mx-auto d-block" width="200"
                                        height="200">
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(Auth::user()->role === 'user'): ?>
                                <?php if(Auth::user()->name === $user->name): ?>
                                    <img src="<?php echo e(asset('img/Users.PNG')); ?>" class="rounded mx-auto d-block" width="200"
                                        height="200">
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <strong>คำเตือน!</strong> มีปัญหาบางอย่างเกี่ยวกับข้อมูลที่คุณป้อน<br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-11">
                                        <div class="form-group">
                                            <strong>ชื่อ:</strong>
                                            <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control"
                                                placeholder="ชื่อ">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-11">
                                        <div class="form-group">
                                            <strong>อีเมล:</strong>
                                            <input type="email" name="email" value="<?php echo e($user->email); ?>"
                                                class="form-control" placeholder="อีเมล">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-11">
                                        <div class="form-group">
                                            <strong>เบอร์โทรศัพท์:</strong>
                                            <input type="text" name="users_phone" value="<?php echo e($user->users_phone); ?>"
                                                class="form-control" placeholder="เบอร์โทรศัพท์">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-11">
                                        <div class="form-group">
                                            <strong>เลขบัตรประชาชน:</strong>
                                            <input type="text" name="users_idcard" value="<?php echo e($user->users_idcard); ?>"
                                                class="form-control" placeholder="เลขบัตรประชาชน">
                                        </div>
                                    </div>

                                    <?php if(Auth::user()): ?>
                                        <?php if(Auth::user()->role === 'admin'): ?>
                                            <div class="col-xs-12 col-sm-12 col-md-11">
                                                <div class="form-group">
                                                    <strong>สถานะ</strong>
                                                    <select class="form-control" id="exampleFormControlSelect1" name="role">
                                                        <?php echo e($user->role); ?>

                                                        <option value="user">user</option>
                                                        <option value="admin">admin</option>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if(Auth::user()): ?>
                                        <?php if(Auth::user()->role === 'user'): ?>
                                            <div class="col-xs-12 col-sm-12 col-md-11">
                                                <div class="form-group">
                                                    <strong>สถานะ</strong>
                                                    <select class="form-control" id="exampleFormControlSelect1" name="role">
                                                        <?php echo e($user->role); ?>

                                                        <option value="user">user</option>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <div class="col-xs-12 col-sm-12 col-md-11 text-center">
                                        <button type="submit" class="btn btn-primary">บันทึก</button>
                                        <a class="btn btn-danger" href="<?php echo e(route('users.index')); ?>"> ย้อนกลับ</a>
                                    </div>
                                </div>

                            </form>
                            

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\Clinic\resources\views/users/edit.blade.php ENDPATH**/ ?>