

<?php $__env->startSection('title', 'Base page'); ?>
<title>Clinic</title>
<?php $__env->startSection('content'); ?>

    <div class="container mt-2">

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()): ?>
            <?php if(Auth::user()->role === 'admin'): ?>

                <div class="row">
                    <div class="col-lg-12 margin-tb">
                        <div class="pull-left">
                            <h4>รายชื่อผู้ใช้งาน</h4>
                        </div>
                    </div>
                </div>

                <table class="table table-bordered">
                    <tr class="text-white" style="background-color:#46a7a2;">
                        <th>ลำดับ</th>
                        <th>ชื่อ-นามสกุล</th>
                        <th>อีเมล</th>
                        <th>เบอร์โทรศัพท์</th>
                        <th>เลขบัตรประชาชน</th>
                        <th>สถานะ</th>
                        <th>แก้ไข | ลบ</th>
                        
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="background-color:#ffffff;">
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->users_phone); ?></td>
                            <td><?php echo e($user->users_idcard); ?></td>
                            <td><?php echo e($user->role); ?></td>
                            <td>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">

                                    

                                    <a class="btn btn-primary" href="<?php echo e(route('users.edit', $user->id)); ?>">แก้ไข</a>

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('ต้องการลบข้อมูลลบข้อมูลคนไข้หรือไม่ ?')">ลบ</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

                <?php echo $users->links(); ?>

            <?php endif; ?>
        <?php endif; ?>

        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::user()->role === 'user'): ?>
                <?php if(Auth::user()->name === $user->name): ?>
                    <div class="card text-info mb-3" style="max-width: 80rem; background-color:#d1dddc;">
                        <div class="card-header bg-white">
                            <h5>ข้อมูลส่วนตัว</h5>
                        </div>
                        <div class="card-body">

                            <div class="card mb-3" style="max-width: 1100px;">
                                <div class="row no-gutters">
                                    <div class="col-md-4">
                                        <img src="<?php echo e(asset('img/Users.PNG')); ?>" class="rounded mx-auto d-block"
                                            width="200" height="200">
                                        
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e(Auth::user()->name); ?> (<?php echo e($user->role); ?>)</h5>
                                            <p class="card-text">อีเมล : <?php echo e($user->email); ?></p>
                                            <p class="card-text">โทร : <?php echo e($user->users_phone); ?></p>
                                            <p class="card-text">เลขบัตรประชาชน : <?php echo e($user->users_idcard); ?></p>
                                            <br><br>
                                            <div>
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">

                                                    

                                                    <a class="btn btn-warning"
                                                        href="<?php echo e(route('users.edit', $user->id)); ?>">แก้ไข</a>

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\Clinic\resources\views/users/index.blade.php ENDPATH**/ ?>