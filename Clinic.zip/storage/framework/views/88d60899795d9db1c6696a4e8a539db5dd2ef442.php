<?php echo e($slot); ?>

<?php /**PATH C:\Users\Asus\EX_Project\Clinic\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>