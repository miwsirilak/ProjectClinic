

<?php $__env->startSection('title', 'Base page'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-2">

        

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        

        <div class="card">
            <h5 class="card-header text-white" style="background-color:#46a7a2;">เลื่อนวันนัดหมาย</h5>
            <div class="card-body" style="background-color:#e8ecec;">
                <form action="<?php echo e(route('events.update', $event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>ชื่อ:</strong>
                                <input type="text" name="title" value="<?php echo e($event->title); ?>" class="form-control"
                                    placeholder="Title">
                            </div>
                        </div>

                        <form>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <label for="party"><strong>วันที่:</strong>
                                    <input type="date" value="<?php echo e($event->date); ?>" name="date" class="form-control">
                                </label>

                                

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="booked" id="booked"
                                        value="จองแล้ว" checked>
                                    <label class="form-check-label" for="booked">
                                        จองคิว
                                    </label>
                                </div>
                            </div>
                        </form>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>อาการ:</strong>
                                <textarea class="form-control" style="height:150px" name="sympotm"
                                    placeholder="Sympotm"><?php echo e($event->sympotm); ?></textarea>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-success">ยืนยันเลื่อนวันนัด</button>
                            <a class="btn btn-danger" href="<?php echo e(route('events.index')); ?>">กลับ</a>
                        </div>
                    </div>

                </form>

            </div>
        </div>

    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('templete.templateadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\EX_Project\login_crud\template\Clinic\resources\views/events/edit.blade.php ENDPATH**/ ?>