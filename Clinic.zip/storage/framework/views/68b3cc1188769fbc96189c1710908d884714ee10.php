<div>
    <h1>Admin Dashboard</h1>
</div>
<?php /**PATH C:\Users\Asus\EX_Project\Clinic\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>